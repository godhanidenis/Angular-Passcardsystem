# Get-iOS-UDID


The UDID for an iPhone and iPad can no longer be retrieved using apps. Instead, we can install a profile using a web page and PHP. The result will be sent to you by e-mail.

You'll need to make edits to the files to insert your web domain name. 

Make the following edits:

enroll.mobileconfig line 8

done.php line 75

submit.php line 3

